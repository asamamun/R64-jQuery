<?php
require "db.php";

$term = $_GET['term'];

$sql = "SELECT film_id, title, description FROM film WHERE title LIKE '%".$term."%' or description LIKE '%".$term."%'";

$result = $conn->query($sql);
$data = array();
while($r = $result->fetch_array(MYSQLI_ASSOC)){
    $data[] = array(
			'label' => $r['title'],
			'value' => $r['title'],
			'id' => $r['film_id']
		);
}
echo json_encode($data);
?>