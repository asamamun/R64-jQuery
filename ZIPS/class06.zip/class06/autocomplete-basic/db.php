<?php
$conn = new mysqli("localhost","root","","sakila");
$conn->set_charset("utf8");
?>