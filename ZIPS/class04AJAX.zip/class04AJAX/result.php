     
     <h2 class="mb-4">Result Table</h2>
        <table class="table table-striped table-<?= $_GET['theme'] ?>">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Name</th>
                    <th scope="col">Subject</th>
                    <th scope="col">Score</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <th scope="row">1</th>
                    <td>John Doe</td>
                    <td>Math</td>
                    <td>95</td>
                </tr>
                <tr>
                    <th scope="row">2</th>
                    <td>Jane Smith</td>
                    <td>Science</td>
                    <td>89</td>
                </tr>
                <tr>
                    <th scope="row">3</th>
                    <td>Sam Johnson</td>
                    <td>History</td>
                    <td>92</td>
                </tr>
            </tbody>
        </table>
