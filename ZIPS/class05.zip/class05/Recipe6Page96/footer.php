<span  class="links" v="home">Home</span> 
<span class="links" v="about">About Us</span> 
<span href="#" class="links" v="projects">Our Projects</span> 
<span href="#" class="links" v="gallery">Gallery</span> 
<span href="#" class="links" v="contact">Contact Us</span>