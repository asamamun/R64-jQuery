this is the project page.jQuery provides a method load()that acts on HTML elements. It gets the data from the server and inserts it into 
the HTML element or elements that called it. load()takes three parameters. The first parameter is theURL, from 
where data will be loaded, the second parameter is the data that can be sent to the server. The third parameter is 
a callback function which executes once data has loaded.