<b>Difference between load and get</b><hr>
Both these methods are similar except for the fact that loadis a method, which means it acts on a set of elements 
specified by a selector. Once the request is complete, the HTML of elements specified by the selectorsis set. On 
the other hand $.getis a global method that has an explicitly defined callback function.