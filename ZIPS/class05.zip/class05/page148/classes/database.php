<?php
$conn = new mysqli("localhost","root","","r53_jquery");
$conn->set_charset("utf8");